import Text "mo:core/Text";
import List "mo:core/List";
import Map "mo:core/Map";
import Array "mo:core/Array";
import Time "mo:core/Time";
import Iter "mo:core/Iter";
import Order "mo:core/Order";
import Principal "mo:core/Principal";
import Runtime "mo:core/Runtime";
import Storage "blob-storage/Storage";
import MixinStorage "blob-storage/Mixin";

actor {
  include MixinStorage();

  type Disease = {
    id : Text;
    name : Text;
    description : Text;
    symptoms : Text;
    prevention : Text;
  };

  module Disease {
    public func compare(disease1 : Disease, disease2 : Disease) : Order.Order {
      switch (Text.compare(disease1.name, disease2.name)) {
        case (#equal) { Text.compare(disease1.description, disease2.description) };
        case (result) { result };
      };
    };
  };

  type Prediction = {
    image : Storage.ExternalBlob;
    diseaseId : Text;
    confidence : Float;
    timestamp : Int;
  };

  type Treatment = {
    diseaseId : Text;
    name : Text;
    description : Text;
    effectiveness : Float;
  };

  // Data Stores
  let diseases = Map.empty<Text, Disease>();
  let predictions = Map.empty<Principal, List.List<Prediction>>();
  let treatments = Map.empty<Text, Treatment>();

  // Add Disease
  public shared ({ caller }) func addDisease(name : Text, description : Text, symptoms : Text, prevention : Text) : async () {
    let id = name;
    if (diseases.containsKey(id)) {
      Runtime.trap("Disease with this name already exists: " # id);
    };
    let disease : Disease = {
      id;
      name;
      description;
      symptoms;
      prevention;
    };
    diseases.add(id, disease);
  };

  // Get All Diseases
  public query ({ caller }) func getAllDiseases() : async [Disease] {
    diseases.values().toArray().sort();
  };

  // Store Prediction
  public shared ({ caller }) func storePrediction(image : Storage.ExternalBlob, diseaseId : Text, confidence : Float) : async () {
    if (not diseases.containsKey(diseaseId)) {
      Runtime.trap("Invalid disease ID: " # diseaseId);
    };
    let newPrediction : Prediction = {
      image;
      diseaseId;
      confidence;
      timestamp = Time.now();
    };

    switch (predictions.get(caller)) {
      case (null) {
        let list = List.empty<Prediction>();
        list.add(newPrediction);
        predictions.add(caller, list);
      };
      case (?existingPredictions) {
        existingPredictions.add(newPrediction);
      };
    };
  };

  // Get User Predictions
  public query ({ caller }) func getUserPredictions() : async [Prediction] {
    switch (predictions.get(caller)) {
      case (null) {
        [];
      };
      case (?userPredictions) {
        userPredictions.toArray();
      };
    };
  };

  // Add Treatment
  public shared ({ caller }) func addTreatment(diseaseId : Text, name : Text, description : Text, effectiveness : Float) : async () {
    if (not diseases.containsKey(diseaseId)) {
      Runtime.trap("Invalid disease ID: " # diseaseId);
    };
    let treatment : Treatment = {
      diseaseId;
      name;
      description;
      effectiveness;
    };
    treatments.add(diseaseId, treatment);
  };

  // Get Treatments for Disease
  public query ({ caller }) func getTreatmentsForDisease(diseaseId : Text) : async [Treatment] {
    if (not diseases.containsKey(diseaseId)) {
      Runtime.trap("Invalid disease ID: " # diseaseId);
    };
    let list = List.empty<Treatment>();
    switch (treatments.get(diseaseId)) {
      case (null) {};
      case (?treatment) {
        list.add(treatment);
      };
    };
    list.toArray();
  };

  // Get Disease By ID
  public query ({ caller }) func getDiseaseById(diseaseId : Text) : async Disease {
    switch (diseases.get(diseaseId)) {
      case (null) { Runtime.trap("Disease not found: " # diseaseId) };
      case (?disease) { disease };
    };
  };

  // Get All Predictions For Admin (fetch all users' predictions)
  public query ({ caller }) func getAllPredictionsForAdmin() : async [(Principal, [Prediction])] {
    let entries = predictions.entries().toArray();
    entries.map(
      func((principal, predictionList)) {
        let predictionsArray = predictionList.toArray();
        (principal, predictionsArray : [Prediction]);
      }
    );
  };
};
