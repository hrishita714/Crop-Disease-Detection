import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import type { Disease, Prediction } from '../backend';
import { ExternalBlob } from '../backend';

export function useGetAllDiseases() {
  const { actor, isFetching } = useActor();

  return useQuery<Disease[]>({
    queryKey: ['diseases'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllDiseases();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useGetDiseaseById(diseaseId: string) {
  const { actor, isFetching } = useActor();

  return useQuery<Disease | null>({
    queryKey: ['disease', diseaseId],
    queryFn: async () => {
      if (!actor || !diseaseId) return null;
      try {
        return await actor.getDiseaseById(diseaseId);
      } catch (error) {
        console.error('Error fetching disease:', error);
        return null;
      }
    },
    enabled: !!actor && !isFetching && !!diseaseId,
  });
}

export function useGetUserPredictions() {
  const { actor, isFetching } = useActor();

  return useQuery<Prediction[]>({
    queryKey: ['predictions'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getUserPredictions();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useStorePrediction() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      image,
      diseaseId,
      confidence,
    }: {
      image: ExternalBlob;
      diseaseId: string;
      confidence: number;
    }) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.storePrediction(image, diseaseId, confidence);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['predictions'] });
    },
  });
}

export function useAddDisease() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      name,
      description,
      symptoms,
      prevention,
    }: {
      name: string;
      description: string;
      symptoms: string;
      prevention: string;
    }) => {
      if (!actor) throw new Error('Actor not initialized');
      return actor.addDisease(name, description, symptoms, prevention);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['diseases'] });
    },
  });
}
