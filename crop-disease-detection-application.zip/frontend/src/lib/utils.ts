import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import type { Disease } from '../backend';
import { sampleDiseases } from './mlModel';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Initialize sample diseases in the backend
 * Call this function once to populate the database with sample data
 */
export async function initializeSampleDiseases(
  addDisease: (params: {
    name: string;
    description: string;
    symptoms: string;
    prevention: string;
  }) => Promise<void>,
  existingDiseases: Disease[]
): Promise<void> {
  // Check if diseases already exist
  if (existingDiseases.length > 0) {
    console.log('Diseases already initialized');
    return;
  }

  console.log('Initializing sample diseases...');
  
  for (const disease of sampleDiseases) {
    try {
      await addDisease(disease);
      console.log(`Added disease: ${disease.name}`);
    } catch (error) {
      console.error(`Failed to add disease ${disease.name}:`, error);
    }
  }
  
  console.log('Sample diseases initialized successfully');
}
