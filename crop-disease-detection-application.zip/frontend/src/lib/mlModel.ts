import type { Disease } from '../backend';

interface PredictionResult {
  diseaseId: string;
  diseaseName: string;
  confidence: number;
  description: string;
}

/**
 * Simulated ML model for crop disease prediction
 * In production, this would be replaced with a real TensorFlow.js model
 */
export async function predictDisease(
  imageFile: File,
  diseases: Disease[]
): Promise<PredictionResult> {
  // Simulate processing time
  await new Promise((resolve) => setTimeout(resolve, 1500));

  if (diseases.length === 0) {
    throw new Error('No diseases available for prediction');
  }

  // Simulate ML prediction by randomly selecting a disease with weighted confidence
  // In production, this would use actual image analysis
  const randomIndex = Math.floor(Math.random() * diseases.length);
  const selectedDisease = diseases[randomIndex];

  // Generate a realistic confidence score (higher probability for higher confidence)
  const confidenceRandom = Math.random();
  let confidence: number;

  if (confidenceRandom < 0.6) {
    // 60% chance of high confidence (0.75-0.95)
    confidence = 0.75 + Math.random() * 0.2;
  } else if (confidenceRandom < 0.9) {
    // 30% chance of medium confidence (0.6-0.75)
    confidence = 0.6 + Math.random() * 0.15;
  } else {
    // 10% chance of low confidence (0.45-0.6)
    confidence = 0.45 + Math.random() * 0.15;
  }

  return {
    diseaseId: selectedDisease.id,
    diseaseName: selectedDisease.name,
    confidence: Math.round(confidence * 100) / 100,
    description: selectedDisease.description,
  };
}

/**
 * Initialize sample diseases in the backend
 * This should be called once to populate the database
 */
export const sampleDiseases = [
  {
    name: 'Late Blight',
    description:
      'A devastating disease affecting tomatoes and potatoes, caused by the water mold Phytophthora infestans.',
    symptoms:
      'Dark brown to black lesions on leaves and stems. White fuzzy growth on undersides of leaves during humid conditions. Rapid plant death in severe cases. Brown, firm rot on fruits and tubers.',
    prevention:
      'Plant resistant varieties. Ensure good air circulation. Avoid overhead watering. Remove infected plants immediately. Apply copper-based fungicides preventively. Rotate crops annually.',
  },
  {
    name: 'Powdery Mildew',
    description:
      'A common fungal disease that appears as white powdery spots on leaves and stems of many crops.',
    symptoms:
      'White or gray powdery coating on leaves, stems, and sometimes fruits. Leaves may curl, yellow, or drop prematurely. Stunted plant growth. Reduced yield and fruit quality.',
    prevention:
      'Provide adequate spacing for air circulation. Water at soil level, not overhead. Remove infected plant parts. Apply sulfur or potassium bicarbonate sprays. Choose resistant varieties.',
  },
  {
    name: 'Bacterial Spot',
    description:
      'A bacterial disease affecting peppers and tomatoes, causing leaf spots and fruit lesions.',
    symptoms:
      'Small, dark brown spots with yellow halos on leaves. Raised, corky spots on fruits. Leaf yellowing and defoliation. Reduced fruit quality and marketability.',
    prevention:
      'Use disease-free seeds and transplants. Avoid working with wet plants. Practice crop rotation. Remove and destroy infected plants. Apply copper-based bactericides.',
  },
  {
    name: 'Fusarium Wilt',
    description:
      'A soil-borne fungal disease that causes wilting and yellowing in many crops including tomatoes and cucumbers.',
    symptoms:
      'Yellowing of lower leaves progressing upward. Wilting during hot days, recovering at night initially. Brown discoloration in vascular tissue. Stunted growth and eventual plant death.',
    prevention:
      'Plant resistant varieties. Practice long crop rotations. Solarize soil before planting. Maintain proper soil pH. Avoid overwatering. Remove infected plants and surrounding soil.',
  },
  {
    name: 'Anthracnose',
    description:
      'A fungal disease affecting fruits and vegetables, causing dark, sunken lesions on fruits and leaves.',
    symptoms:
      'Circular, sunken spots on fruits with dark centers. Leaf spots with concentric rings. Premature fruit drop. Pink or orange spore masses in humid conditions.',
    prevention:
      'Remove crop debris after harvest. Rotate crops for 2-3 years. Avoid overhead irrigation. Apply fungicides during wet weather. Harvest fruits promptly when ripe.',
  },
  {
    name: 'Downy Mildew',
    description:
      'A disease caused by water molds affecting cucurbits, lettuce, and other crops with characteristic yellow patches.',
    symptoms:
      'Yellow patches on upper leaf surfaces. Gray or purple fuzzy growth on undersides. Angular leaf spots following veins. Rapid defoliation in severe cases.',
    prevention:
      'Plant resistant varieties. Improve air circulation. Water early in the day. Remove infected leaves. Apply copper fungicides preventively. Avoid working with wet plants.',
  },
  {
    name: 'Septoria Leaf Spot',
    description:
      'A fungal disease primarily affecting tomatoes, characterized by numerous small spots on leaves.',
    symptoms:
      'Small, circular spots with dark borders and gray centers. Black specks (fruiting bodies) in spot centers. Lower leaves affected first. Progressive defoliation from bottom up.',
    prevention:
      'Mulch around plants to prevent soil splash. Remove lower leaves touching soil. Space plants adequately. Rotate crops for 3 years. Apply fungicides when symptoms first appear.',
  },
  {
    name: 'Mosaic Virus',
    description:
      'A viral disease causing mottled patterns on leaves of various crops including tomatoes, peppers, and cucumbers.',
    symptoms:
      'Mottled light and dark green patterns on leaves. Distorted, curled, or stunted leaves. Reduced fruit size and yield. Stunted plant growth. Fruit may show color breaking.',
    prevention:
      'Use virus-free seeds and transplants. Control aphids and other vectors. Remove infected plants immediately. Disinfect tools between plants. Plant resistant varieties. Control weeds that harbor viruses.',
  },
];
