import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sprout, Droplets, Sun, Thermometer, Leaf, Beaker } from 'lucide-react';

export default function CropCarePage() {
  const careCategories = [
    {
      id: 'soil',
      label: 'Soil Health',
      icon: Sprout,
      content: {
        title: 'Maintaining Healthy Soil',
        description: 'Healthy soil is the foundation of successful crop production',
        sections: [
          {
            title: 'Soil Testing',
            items: [
              'Test soil pH and nutrient levels annually',
              'Collect samples from multiple locations',
              'Test at the same time each year for consistency',
              'Follow lab recommendations for amendments',
            ],
          },
          {
            title: 'Organic Matter',
            items: [
              'Add compost or well-rotted manure regularly',
              'Use cover crops to improve soil structure',
              'Maintain 3-5% organic matter content',
              'Avoid excessive tillage to preserve soil life',
            ],
          },
          {
            title: 'Soil Structure',
            items: [
              'Prevent compaction by limiting traffic',
              'Use raised beds in poorly drained areas',
              'Add gypsum to improve clay soils',
              'Mulch to protect soil surface',
            ],
          },
        ],
      },
    },
    {
      id: 'water',
      label: 'Irrigation',
      icon: Droplets,
      content: {
        title: 'Effective Water Management',
        description: 'Proper irrigation ensures optimal plant growth and disease prevention',
        sections: [
          {
            title: 'Watering Schedule',
            items: [
              'Water deeply but less frequently',
              'Adjust based on weather and soil type',
              'Water early morning for best results',
              'Monitor soil moisture regularly',
            ],
          },
          {
            title: 'Irrigation Methods',
            items: [
              'Drip irrigation for water efficiency',
              'Soaker hoses for garden beds',
              'Avoid overhead watering when possible',
              'Use mulch to retain soil moisture',
            ],
          },
          {
            title: 'Water Quality',
            items: [
              'Test water for salinity and pH',
              'Filter water if necessary',
              'Collect rainwater when possible',
              'Monitor for contaminants',
            ],
          },
        ],
      },
    },
    {
      id: 'nutrients',
      label: 'Nutrition',
      icon: Beaker,
      content: {
        title: 'Crop Nutrition Management',
        description: 'Balanced nutrition is essential for healthy, disease-resistant crops',
        sections: [
          {
            title: 'Macronutrients',
            items: [
              'Nitrogen (N): Essential for leaf growth',
              'Phosphorus (P): Promotes root development',
              'Potassium (K): Improves disease resistance',
              'Apply based on soil test results',
            ],
          },
          {
            title: 'Micronutrients',
            items: [
              'Iron, zinc, and manganese for enzyme function',
              'Boron for cell wall development',
              'Copper for disease resistance',
              'Apply foliar sprays if deficient',
            ],
          },
          {
            title: 'Fertilizer Application',
            items: [
              'Split applications for better uptake',
              'Side-dress during active growth',
              'Use slow-release formulations',
              'Avoid over-fertilization',
            ],
          },
        ],
      },
    },
    {
      id: 'climate',
      label: 'Climate',
      icon: Sun,
      content: {
        title: 'Climate Considerations',
        description: 'Understanding and adapting to climate conditions',
        sections: [
          {
            title: 'Temperature Management',
            items: [
              'Know optimal temperature ranges for crops',
              'Use row covers for frost protection',
              'Provide shade in extreme heat',
              'Monitor temperature fluctuations',
            ],
          },
          {
            title: 'Light Requirements',
            items: [
              'Ensure 6-8 hours of sunlight daily',
              'Prune to improve light penetration',
              'Orient rows north-south when possible',
              'Use reflective mulches to increase light',
            ],
          },
          {
            title: 'Wind Protection',
            items: [
              'Plant windbreaks for exposed areas',
              'Stake tall or heavy crops',
              'Use row covers in windy conditions',
              'Select wind-tolerant varieties',
            ],
          },
        ],
      },
    },
    {
      id: 'maintenance',
      label: 'Maintenance',
      icon: Leaf,
      content: {
        title: 'Regular Crop Maintenance',
        description: 'Consistent care practices for optimal crop health',
        sections: [
          {
            title: 'Pruning & Training',
            items: [
              'Remove diseased or damaged plant parts',
              'Prune for better air circulation',
              'Train vining crops on supports',
              'Pinch back to encourage bushiness',
            ],
          },
          {
            title: 'Weed Control',
            items: [
              'Remove weeds before they set seed',
              'Use mulch to suppress weed growth',
              'Hand-pull weeds when small',
              'Maintain weed-free borders',
            ],
          },
          {
            title: 'Monitoring',
            items: [
              'Inspect crops at least twice weekly',
              'Look for signs of pests or disease',
              'Check soil moisture levels',
              'Document observations and actions',
            ],
          },
        ],
      },
    },
  ];

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
            Crop Care & Maintenance
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Essential guidelines for maintaining healthy crops and maximizing yields
          </p>
        </div>

        <Tabs defaultValue="soil" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 lg:grid-cols-5 h-auto">
            {careCategories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="flex items-center gap-2 py-3"
              >
                <category.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{category.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          {careCategories.map((category) => (
            <TabsContent key={category.id} value={category.id} className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500/10 to-green-500/10">
                      <category.icon className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div>
                      <CardTitle>{category.content.title}</CardTitle>
                      <CardDescription>{category.content.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 md:grid-cols-3">
                    {category.content.sections.map((section, index) => (
                      <div key={index} className="space-y-3">
                        <h3 className="font-semibold text-sm">{section.title}</h3>
                        <ul className="space-y-2">
                          {section.items.map((item, itemIndex) => (
                            <li
                              key={itemIndex}
                              className="flex items-start gap-2 text-sm text-muted-foreground"
                            >
                              <div className="h-1.5 w-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-1.5 shrink-0" />
                              <span>{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>

        {/* Seasonal Care Tips */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Seasonal Care Calendar</CardTitle>
            <CardDescription>Key activities throughout the growing season</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Sprout className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                  Spring
                </h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Prepare soil and beds</li>
                  <li>• Start seeds indoors</li>
                  <li>• Apply pre-emergent herbicides</li>
                  <li>• Install irrigation systems</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Sun className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
                  Summer
                </h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Monitor water needs closely</li>
                  <li>• Scout for pests regularly</li>
                  <li>• Harvest crops at peak</li>
                  <li>• Maintain consistent care</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Leaf className="h-4 w-4 text-orange-600 dark:text-orange-400" />
                  Fall
                </h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Plant cover crops</li>
                  <li>• Clean up crop debris</li>
                  <li>• Test and amend soil</li>
                  <li>• Store equipment properly</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm flex items-center gap-2">
                  <Thermometer className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  Winter
                </h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Plan next season</li>
                  <li>• Order seeds and supplies</li>
                  <li>• Maintain equipment</li>
                  <li>• Review records</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
