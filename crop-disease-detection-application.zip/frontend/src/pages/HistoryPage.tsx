import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle, History, ExternalLink } from 'lucide-react';
import { useGetUserPredictions, useGetAllDiseases } from '../hooks/useQueries';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { Link } from '@tanstack/react-router';
import { useMemo } from 'react';

export default function HistoryPage() {
  const { identity, login, isLoginSuccess } = useInternetIdentity();
  const { data: predictions, isLoading, error } = useGetUserPredictions();
  const { data: diseases } = useGetAllDiseases();

  const predictionsWithDetails = useMemo(() => {
    if (!predictions || !diseases) return [];
    return predictions.map((prediction) => {
      const disease = diseases.find((d) => d.id === prediction.diseaseId);
      return {
        ...prediction,
        diseaseName: disease?.name || 'Unknown Disease',
      };
    });
  }, [predictions, diseases]);

  const formatDate = (timestamp: bigint) => {
    const date = new Date(Number(timestamp) / 1000000);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (!isLoginSuccess || !identity) {
    return (
      <div className="container py-8 md:py-12">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <History className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="font-semibold mb-2">Login Required</h3>
              <p className="text-sm text-muted-foreground text-center mb-6">
                Please login to view your prediction history
              </p>
              <Button onClick={login}>Login</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-2">
            Prediction History
          </h1>
          <p className="text-lg text-muted-foreground">
            View all your past crop disease detections and analyses
          </p>
        </div>

        {isLoading && (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mb-4" />
            <p className="text-sm text-muted-foreground">Loading your history...</p>
          </div>
        )}

        {error && (
          <Card className="border-destructive">
            <CardContent className="flex items-center gap-4 py-8">
              <AlertCircle className="h-8 w-8 text-destructive" />
              <div>
                <h3 className="font-semibold">Failed to load history</h3>
                <p className="text-sm text-muted-foreground">
                  Please try again later or contact support
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {!isLoading && !error && predictionsWithDetails.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <History className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="font-semibold mb-2">No predictions yet</h3>
              <p className="text-sm text-muted-foreground text-center mb-6">
                Start by uploading an image to detect crop diseases
              </p>
              <Button asChild>
                <Link to="/detect">Start Detection</Link>
              </Button>
            </CardContent>
          </Card>
        )}

        {!isLoading && !error && predictionsWithDetails.length > 0 && (
          <div className="space-y-4">
            {predictionsWithDetails.map((prediction, index) => (
              <Card
                key={index}
                className="hover:shadow-lg transition-all duration-300 hover:border-emerald-200 dark:hover:border-emerald-800"
              >
                <CardHeader>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {prediction.diseaseName}
                        <Badge
                          variant={
                            prediction.confidence > 0.8
                              ? 'default'
                              : prediction.confidence > 0.6
                                ? 'secondary'
                                : 'outline'
                          }
                        >
                          {(prediction.confidence * 100).toFixed(1)}% confidence
                        </Badge>
                      </CardTitle>
                      <CardDescription>{formatDate(prediction.timestamp)}</CardDescription>
                    </div>
                    <Button asChild variant="outline" size="sm">
                      <Link to="/diseases/$diseaseId" params={{ diseaseId: prediction.diseaseId }}>
                        View Details <ExternalLink className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-start gap-4">
                    <img
                      src={prediction.image.getDirectURL()}
                      alt="Analyzed crop"
                      className="w-32 h-32 object-cover rounded-lg border border-border"
                    />
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm mb-2">Analysis Summary</h4>
                      <p className="text-sm text-muted-foreground">
                        This image was analyzed and identified as showing signs of{' '}
                        {prediction.diseaseName.toLowerCase()} with a confidence level of{' '}
                        {(prediction.confidence * 100).toFixed(1)}%.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
