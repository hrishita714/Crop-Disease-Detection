import { Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Scan, BookOpen, Shield, Sprout, ArrowRight, History } from 'lucide-react';
import { useEffect } from 'react';
import { useGetAllDiseases, useAddDisease } from '../hooks/useQueries';
import { initializeSampleDiseases } from '../lib/utils';

export default function HomePage() {
  const { data: diseases } = useGetAllDiseases();
  const addDisease = useAddDisease();

  // Initialize sample diseases on first load
  useEffect(() => {
    if (diseases && diseases.length === 0) {
      initializeSampleDiseases(addDisease.mutateAsync, diseases);
    }
  }, [diseases]);

  const features = [
    {
      icon: Scan,
      title: 'AI-Powered Detection',
      description: 'Upload crop images and get instant disease detection with confidence scores',
      link: '/detect',
    },
    {
      icon: BookOpen,
      title: 'Disease Database',
      description: 'Comprehensive information about crop diseases, symptoms, and treatments',
      link: '/diseases',
    },
    {
      icon: Shield,
      title: 'Prevention Strategies',
      description: 'Learn effective methods to prevent crop diseases before they occur',
      link: '/prevention',
    },
    {
      icon: Sprout,
      title: 'Crop Care Tips',
      description: 'Expert guidance on maintaining healthy crops and optimal growing conditions',
      link: '/crop-care',
    },
  ];

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-emerald-50/50 to-background dark:from-emerald-950/20">
        <div className="container py-16 md:py-24 lg:py-32">
          <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col gap-6">
              <div className="inline-flex items-center rounded-full border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1 text-sm font-medium text-emerald-700 dark:text-emerald-300 w-fit">
                <Sprout className="mr-2 h-4 w-4" />
                AI-Powered Crop Protection
              </div>
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
                Protect Your Crops with{' '}
                <span className="bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  AI Detection
                </span>
              </h1>
              <p className="text-lg text-muted-foreground md:text-xl">
                Upload images of your crops and instantly detect diseases with our advanced machine
                learning technology. Get actionable insights to protect your harvest.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700">
                  <Link to="/detect">
                    Start Detection <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link to="/diseases">Browse Diseases</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-tr from-emerald-500/20 to-green-500/20 blur-3xl" />
              <img
                src="/assets/generated/hero-image.dim_1200x600.jpg"
                alt="Crop disease detection"
                className="relative rounded-2xl shadow-2xl border border-border/50"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container py-16 md:py-24">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
            Everything You Need for Crop Health
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive tools and information to keep your crops healthy and productive
          </p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <Card
              key={feature.title}
              className="group hover:shadow-lg transition-all duration-300 hover:border-emerald-200 dark:hover:border-emerald-800"
            >
              <CardHeader>
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500/10 to-green-500/10 group-hover:from-emerald-500/20 group-hover:to-green-500/20 transition-colors">
                  <feature.icon className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />
                </div>
                <CardTitle className="mt-4">{feature.title}</CardTitle>
                <CardDescription>{feature.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="ghost" className="w-full justify-start p-0 h-auto font-medium text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300">
                  <Link to={feature.link}>
                    Learn more <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* How It Works Section */}
      <section className="bg-muted/50 py-16 md:py-24">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
              How It Works
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Simple steps to protect your crops from diseases
            </p>
          </div>
          <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-green-600 text-white font-bold text-xl mb-4">
                1
              </div>
              <h3 className="text-xl font-semibold mb-2">Upload Image</h3>
              <p className="text-muted-foreground">
                Take a clear photo of your crop showing any symptoms or affected areas
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-green-600 text-white font-bold text-xl mb-4">
                2
              </div>
              <h3 className="text-xl font-semibold mb-2">AI Analysis</h3>
              <p className="text-muted-foreground">
                Our machine learning model analyzes the image and identifies potential diseases
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-500 to-green-600 text-white font-bold text-xl mb-4">
                3
              </div>
              <h3 className="text-xl font-semibold mb-2">Get Results</h3>
              <p className="text-muted-foreground">
                Receive detailed information about the disease and recommended prevention methods
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-emerald-600 to-green-600 text-white">
        <div className="container py-16 md:py-24">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
              Ready to Protect Your Crops?
            </h2>
            <p className="text-lg text-emerald-50 mb-8">
              Start detecting crop diseases today with our AI-powered platform. Upload an image and
              get instant results.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" variant="secondary">
                <Link to="/detect">
                  Get Started Now <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
                <Link to="/history">
                  <History className="mr-2 h-4 w-4" />
                  View History
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
