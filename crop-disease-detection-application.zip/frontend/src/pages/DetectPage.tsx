import { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, Loader2, AlertCircle, CheckCircle2, Camera, ImageIcon } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { useStorePrediction, useGetAllDiseases } from '../hooks/useQueries';
import { ExternalBlob } from '../backend';
import { toast } from 'sonner';
import { Link } from '@tanstack/react-router';
import { useInternetIdentity } from '../hooks/useInternetIdentity';
import { predictDisease } from '../lib/mlModel';

interface PredictionResult {
  diseaseId: string;
  diseaseName: string;
  confidence: number;
  description: string;
}

export default function DetectPage() {
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { identity, login, isLoginSuccess } = useInternetIdentity();
  const storePrediction = useStorePrediction();
  const { data: diseases } = useGetAllDiseases();

  const handleImageSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      toast.error('Please select a valid image file');
      return;
    }
    
    if (file.size > 10 * 1024 * 1024) {
      toast.error('Image size must be less than 10MB');
      return;
    }

    setSelectedImage(file);
    setPredictionResult(null);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleImageSelect(file);
    }
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleImageSelect(file);
    }
  }, []);

  const handleAnalyze = async () => {
    if (!selectedImage || !diseases || diseases.length === 0) {
      toast.error('Unable to analyze. Please try again.');
      return;
    }

    if (!isLoginSuccess) {
      toast.error('Please login to save your predictions');
      login();
      return;
    }

    setIsAnalyzing(true);
    setPredictionResult(null);
    setUploadProgress(0);

    try {
      // Simulate ML analysis with progress
      for (let i = 0; i <= 80; i += 10) {
        setUploadProgress(i);
        await new Promise((resolve) => setTimeout(resolve, 150));
      }

      // Get prediction from simulated ML model
      const prediction = await predictDisease(selectedImage, diseases);

      setUploadProgress(90);
      setPredictionResult(prediction);

      // Convert image to bytes and store prediction
      const reader = new FileReader();
      reader.onloadend = async () => {
        const arrayBuffer = reader.result as ArrayBuffer;
        const uint8Array = new Uint8Array(arrayBuffer);
        
        const blob = ExternalBlob.fromBytes(uint8Array).withUploadProgress((percentage) => {
          setUploadProgress(90 + (percentage * 0.1));
        });

        await storePrediction.mutateAsync({
          image: blob,
          diseaseId: prediction.diseaseId,
          confidence: prediction.confidence,
        });

        setUploadProgress(100);
        toast.success('Analysis complete and saved to your history!');
      };
      reader.readAsArrayBuffer(selectedImage);
    } catch (error) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze image. Please try again.');
      setPredictionResult(null);
    } finally {
      setIsAnalyzing(false);
      setTimeout(() => setUploadProgress(0), 1000);
    }
  };

  const handleReset = () => {
    setSelectedImage(null);
    setImagePreview(null);
    setPredictionResult(null);
    setUploadProgress(0);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
            Crop Disease Detection
          </h1>
          <p className="text-lg text-muted-foreground">
            Upload an image of your crop to detect potential diseases using AI
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          {/* Upload Section */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Upload Image</CardTitle>
              <CardDescription>
                Select a clear image of the affected crop for best results
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 cursor-pointer ${
                  isDragging
                    ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20 scale-[1.02]'
                    : imagePreview
                      ? 'border-border hover:border-emerald-400'
                      : 'border-border hover:border-emerald-500'
                }`}
                onClick={() => !isAnalyzing && fileInputRef.current?.click()}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
              >
                {imagePreview ? (
                  <div className="space-y-4">
                    <div className="relative group">
                      <img
                        src={imagePreview}
                        alt="Preview"
                        className="max-h-64 mx-auto rounded-lg shadow-md"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                        <ImageIcon className="h-8 w-8 text-white" />
                      </div>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleReset();
                      }}
                      disabled={isAnalyzing}
                    >
                      Change Image
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex justify-center">
                      <div className={`flex h-16 w-16 items-center justify-center rounded-full transition-all ${
                        isDragging 
                          ? 'bg-emerald-100 dark:bg-emerald-900/50 scale-110' 
                          : 'bg-emerald-50 dark:bg-emerald-950/50'
                      }`}>
                        <Upload className={`h-8 w-8 text-emerald-600 dark:text-emerald-400 transition-transform ${
                          isDragging ? 'scale-110' : ''
                        }`} />
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-medium">
                        {isDragging ? 'Drop image here' : 'Click to upload or drag and drop'}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        PNG, JPG, JPEG up to 10MB
                      </p>
                    </div>
                  </div>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileInputChange}
                className="hidden"
                disabled={isAnalyzing}
              />

              {selectedImage && !predictionResult && (
                <Button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing}
                  className="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Camera className="mr-2 h-4 w-4" />
                      Analyze Image
                    </>
                  )}
                </Button>
              )}

              {isAnalyzing && uploadProgress > 0 && (
                <div className="space-y-2">
                  <Progress value={uploadProgress} className="h-2" />
                  <p className="text-xs text-center text-muted-foreground">
                    {uploadProgress < 80 ? 'Analyzing image...' : uploadProgress < 95 ? 'Saving results...' : 'Complete!'} {uploadProgress.toFixed(0)}%
                  </p>
                </div>
              )}

              {predictionResult && (
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="w-full"
                >
                  Analyze Another Image
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Results Section */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle>Analysis Results</CardTitle>
              <CardDescription>
                AI-powered disease detection results will appear here
              </CardDescription>
            </CardHeader>
            <CardContent>
              {!predictionResult && !isAnalyzing && (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted mb-4">
                    <AlertCircle className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Upload and analyze an image to see results
                  </p>
                </div>
              )}

              {isAnalyzing && (
                <div className="flex flex-col items-center justify-center py-12">
                  <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mb-4" />
                  <p className="text-sm text-muted-foreground">
                    Analyzing image with AI model...
                  </p>
                </div>
              )}

              {predictionResult && (
                <div className="space-y-4 animate-in fade-in duration-500">
                  <Alert className="border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/20">
                    <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                    <AlertTitle className="text-emerald-900 dark:text-emerald-100">
                      Detection Complete
                    </AlertTitle>
                    <AlertDescription className="text-emerald-800 dark:text-emerald-200">
                      Analysis completed successfully
                    </AlertDescription>
                  </Alert>

                  <div className="space-y-3">
                    <div>
                      <h3 className="text-lg font-semibold mb-1">
                        {predictionResult.diseaseName}
                      </h3>
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {predictionResult.description}
                      </p>
                    </div>

                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span className="font-medium">Confidence Level</span>
                        <span className={`font-semibold ${
                          predictionResult.confidence > 0.8 
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : predictionResult.confidence > 0.6
                              ? 'text-yellow-600 dark:text-yellow-400'
                              : 'text-orange-600 dark:text-orange-400'
                        }`}>
                          {(predictionResult.confidence * 100).toFixed(1)}%
                        </span>
                      </div>
                      <Progress
                        value={predictionResult.confidence * 100}
                        className="h-2"
                      />
                      {predictionResult.confidence < 0.7 && (
                        <p className="text-xs text-muted-foreground mt-2">
                          Lower confidence may indicate unclear image or multiple conditions
                        </p>
                      )}
                    </div>

                    <div className="flex flex-col gap-2">
                      <Button asChild className="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700">
                        <Link to="/diseases/$diseaseId" params={{ diseaseId: predictionResult.diseaseId }}>
                          View Full Details
                        </Link>
                      </Button>
                      <Button asChild variant="outline" className="w-full">
                        <Link to="/history">
                          View History
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tips Section */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Tips for Best Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-muted-foreground">Take photos in good lighting conditions</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-muted-foreground">Focus on the affected area of the plant</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-muted-foreground">Ensure the image is clear and not blurry</span>
              </div>
              <div className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-muted-foreground">Include leaves, stems, or fruits showing symptoms</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
