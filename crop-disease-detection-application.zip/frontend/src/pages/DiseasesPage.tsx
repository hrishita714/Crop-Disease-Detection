import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, Loader2, AlertCircle } from 'lucide-react';
import { useState } from 'react';
import { useGetAllDiseases } from '../hooks/useQueries';
import { Link } from '@tanstack/react-router';

export default function DiseasesPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const { data: diseases, isLoading, error } = useGetAllDiseases();

  const filteredDiseases = diseases?.filter(
    (disease) =>
      disease.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      disease.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
            Crop Disease Database
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive information about common crop diseases, their symptoms, and prevention
            methods
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search diseases..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="flex flex-col items-center justify-center py-12">
            <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mb-4" />
            <p className="text-sm text-muted-foreground">Loading diseases...</p>
          </div>
        )}

        {/* Error State */}
        {error && (
          <Card className="border-destructive">
            <CardContent className="flex items-center gap-4 py-8">
              <AlertCircle className="h-8 w-8 text-destructive" />
              <div>
                <h3 className="font-semibold">Failed to load diseases</h3>
                <p className="text-sm text-muted-foreground">
                  Please try again later or contact support
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Empty State */}
        {!isLoading && !error && filteredDiseases?.length === 0 && (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="font-semibold mb-2">No diseases found</h3>
              <p className="text-sm text-muted-foreground text-center">
                {searchQuery
                  ? 'Try adjusting your search query'
                  : 'No diseases have been added yet'}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Diseases Grid */}
        {!isLoading && !error && filteredDiseases && filteredDiseases.length > 0 && (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {filteredDiseases.map((disease) => (
              <Card
                key={disease.id}
                className="group hover:shadow-lg transition-all duration-300 hover:border-emerald-200 dark:hover:border-emerald-800"
              >
                <CardHeader>
                  <CardTitle className="line-clamp-1">{disease.name}</CardTitle>
                  <CardDescription className="line-clamp-2">
                    {disease.description}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button asChild variant="outline" className="w-full">
                    <Link to="/diseases/$diseaseId" params={{ diseaseId: disease.id }}>
                      View Details
                    </Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
