import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Droplets, Sun, Wind, Sprout, Bug } from 'lucide-react';

export default function PreventionPage() {
  const preventionStrategies = [
    {
      icon: Sprout,
      title: 'Crop Rotation',
      description:
        'Rotate crops regularly to prevent soil-borne diseases and reduce pest populations. Different crops have different nutrient requirements and pest vulnerabilities.',
      tips: [
        'Plan a 3-4 year rotation cycle',
        'Avoid planting the same family of crops consecutively',
        'Include legumes to improve soil nitrogen',
        'Keep detailed records of planting patterns',
      ],
    },
    {
      icon: Droplets,
      title: 'Water Management',
      description:
        'Proper irrigation practices can significantly reduce disease occurrence. Excess moisture creates ideal conditions for many pathogens.',
      tips: [
        'Water early in the morning to allow foliage to dry',
        'Use drip irrigation instead of overhead watering',
        'Ensure proper drainage in fields',
        'Monitor soil moisture levels regularly',
      ],
    },
    {
      icon: Sun,
      title: 'Sunlight & Spacing',
      description:
        'Adequate sunlight and air circulation help keep plants dry and reduce disease pressure. Proper spacing is crucial for plant health.',
      tips: [
        'Follow recommended plant spacing guidelines',
        'Prune plants to improve air circulation',
        'Remove weeds that compete for light',
        'Orient rows to maximize sun exposure',
      ],
    },
    {
      icon: Shield,
      title: 'Disease-Resistant Varieties',
      description:
        'Select crop varieties bred for disease resistance. This is one of the most effective and environmentally friendly prevention methods.',
      tips: [
        'Research resistant varieties for your region',
        'Choose certified disease-free seeds',
        'Consider hybrid varieties with multiple resistances',
        'Stay updated on new resistant cultivars',
      ],
    },
    {
      icon: Bug,
      title: 'Integrated Pest Management',
      description:
        'Use a combination of biological, cultural, and chemical methods to manage pests and diseases effectively while minimizing environmental impact.',
      tips: [
        'Monitor crops regularly for early detection',
        'Encourage beneficial insects',
        'Use organic pesticides when necessary',
        'Remove and destroy infected plant material',
      ],
    },
    {
      icon: Wind,
      title: 'Sanitation Practices',
      description:
        'Maintain clean growing environments to prevent disease spread. Good sanitation is fundamental to disease prevention.',
      tips: [
        'Clean and disinfect tools between uses',
        'Remove crop debris after harvest',
        'Control weeds that harbor pests and diseases',
        'Quarantine new plants before introducing them',
      ],
    },
  ];

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-4">
            Disease Prevention Strategies
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Proactive measures to protect your crops and prevent disease outbreaks
          </p>
        </div>

        {/* Hero Card */}
        <Card className="mb-8 bg-gradient-to-r from-emerald-50 to-green-50 dark:from-emerald-950/20 dark:to-green-950/20 border-emerald-200 dark:border-emerald-800">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-green-600 shrink-0">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold mb-2">Prevention is Key</h2>
                <p className="text-muted-foreground">
                  Implementing preventive measures is more effective and economical than treating
                  diseases after they occur. A comprehensive prevention strategy combines multiple
                  approaches to create a robust defense system for your crops.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Prevention Strategies Grid */}
        <div className="grid gap-6 md:grid-cols-2">
          {preventionStrategies.map((strategy) => (
            <Card
              key={strategy.title}
              className="hover:shadow-lg transition-all duration-300 hover:border-emerald-200 dark:hover:border-emerald-800"
            >
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500/10 to-green-500/10">
                    <strategy.icon className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                  </div>
                  <CardTitle>{strategy.title}</CardTitle>
                </div>
                <CardDescription>{strategy.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold text-foreground">Key Practices:</h4>
                  <ul className="space-y-2">
                    {strategy.tips.map((tip, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <div className="h-1.5 w-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-1.5 shrink-0" />
                        <span>{tip}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Tips */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>General Prevention Guidelines</CardTitle>
            <CardDescription>
              Universal practices that apply to all crop disease prevention
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Before Planting</h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Test and amend soil as needed</li>
                  <li>• Choose appropriate planting dates</li>
                  <li>• Prepare seedbeds properly</li>
                  <li>• Use certified disease-free seeds</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">During Growing Season</h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Scout fields regularly</li>
                  <li>• Maintain optimal nutrition</li>
                  <li>• Control weeds promptly</li>
                  <li>• Document observations</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">After Harvest</h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Remove all crop residues</li>
                  <li>• Clean equipment thoroughly</li>
                  <li>• Plan next season's rotation</li>
                  <li>• Store seeds properly</li>
                </ul>
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Year-Round</h4>
                <ul className="space-y-1 text-sm text-muted-foreground">
                  <li>• Keep detailed records</li>
                  <li>• Stay informed about new threats</li>
                  <li>• Network with other farmers</li>
                  <li>• Attend training workshops</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
