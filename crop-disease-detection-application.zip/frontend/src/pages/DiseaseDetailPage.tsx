import { useParams, Link } from '@tanstack/react-router';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Loader2, AlertCircle, Shield, Stethoscope } from 'lucide-react';
import { useGetDiseaseById } from '../hooks/useQueries';
import { Badge } from '@/components/ui/badge';

export default function DiseaseDetailPage() {
  const { diseaseId } = useParams({ from: '/diseases/$diseaseId' });
  const { data: disease, isLoading, error } = useGetDiseaseById(diseaseId);

  if (isLoading) {
    return (
      <div className="container py-8 md:py-12">
        <div className="flex flex-col items-center justify-center py-12">
          <Loader2 className="h-12 w-12 animate-spin text-emerald-600 mb-4" />
          <p className="text-sm text-muted-foreground">Loading disease information...</p>
        </div>
      </div>
    );
  }

  if (error || !disease) {
    return (
      <div className="container py-8 md:py-12">
        <Card className="border-destructive max-w-2xl mx-auto">
          <CardContent className="flex items-center gap-4 py-8">
            <AlertCircle className="h-8 w-8 text-destructive" />
            <div>
              <h3 className="font-semibold">Disease not found</h3>
              <p className="text-sm text-muted-foreground">
                The requested disease information could not be loaded
              </p>
            </div>
          </CardContent>
        </Card>
        <div className="text-center mt-6">
          <Button asChild variant="outline">
            <Link to="/diseases">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Diseases
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8 md:py-12">
      <div className="max-w-4xl mx-auto">
        <Button asChild variant="ghost" className="mb-6">
          <Link to="/diseases">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Diseases
          </Link>
        </Button>

        <div className="space-y-6">
          {/* Header */}
          <div>
            <h1 className="text-3xl font-bold tracking-tight sm:text-4xl mb-2">
              {disease.name}
            </h1>
            <p className="text-lg text-muted-foreground">{disease.description}</p>
          </div>

          <Separator />

          {/* Symptoms Section */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-red-500/10 to-orange-500/10">
                  <Stethoscope className="h-5 w-5 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <CardTitle>Symptoms</CardTitle>
                  <CardDescription>Common signs of this disease</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p className="whitespace-pre-line">{disease.symptoms}</p>
              </div>
            </CardContent>
          </Card>

          {/* Prevention Section */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500/10 to-green-500/10">
                  <Shield className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />
                </div>
                <div>
                  <CardTitle>Prevention & Treatment</CardTitle>
                  <CardDescription>How to prevent and manage this disease</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                <p className="whitespace-pre-line">{disease.prevention}</p>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-gradient-to-r from-emerald-50 to-green-50 dark:from-emerald-950/20 dark:to-green-950/20 border-emerald-200 dark:border-emerald-800">
            <CardContent className="pt-6">
              <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
                <div>
                  <h3 className="font-semibold mb-1">Need to detect this disease?</h3>
                  <p className="text-sm text-muted-foreground">
                    Upload an image for AI-powered analysis
                  </p>
                </div>
                <Button asChild className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 shrink-0">
                  <Link to="/detect">Start Detection</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
