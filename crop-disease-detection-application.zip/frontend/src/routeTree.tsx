import { createRootRoute, createRoute, Outlet } from '@tanstack/react-router';
import Layout from './components/Layout';
import HomePage from './pages/HomePage';
import DetectPage from './pages/DetectPage';
import DiseasesPage from './pages/DiseasesPage';
import DiseaseDetailPage from './pages/DiseaseDetailPage';
import PreventionPage from './pages/PreventionPage';
import CropCarePage from './pages/CropCarePage';
import HistoryPage from './pages/HistoryPage';

const rootRoute = createRootRoute({
  component: () => (
    <Layout>
      <Outlet />
    </Layout>
  ),
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: HomePage,
});

const detectRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/detect',
  component: DetectPage,
});

const diseasesRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/diseases',
  component: DiseasesPage,
});

const diseaseDetailRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/diseases/$diseaseId',
  component: DiseaseDetailPage,
});

const preventionRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/prevention',
  component: PreventionPage,
});

const cropCareRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/crop-care',
  component: CropCarePage,
});

const historyRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/history',
  component: HistoryPage,
});

export const routeTree = rootRoute.addChildren([
  indexRoute,
  detectRoute,
  diseasesRoute,
  diseaseDetailRoute,
  preventionRoute,
  cropCareRoute,
  historyRoute,
]);
